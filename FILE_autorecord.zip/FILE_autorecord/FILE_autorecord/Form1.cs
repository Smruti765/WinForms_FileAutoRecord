﻿using System;
using System.IO;
using System.Windows.Forms;

namespace FILE_autorecord
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            InitializeGrid();
        }

        private void InitializeGrid()
        {
            dgvData.ColumnCount = 5;
            dgvData.Columns[0].Name = "Name";
            dgvData.Columns[1].Name = "Age";
            dgvData.Columns[2].Name = "Email";
            dgvData.Columns[3].Name = "Date";
            dgvData.Columns[4].Name = "Time";
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            string name = txtName.Text.Trim();
            string age = txtAge.Text.Trim();
            string email = txtEmail.Text.Trim();
            string date = DateTime.Now.ToString("dd-MM-yyyy");
            string time = DateTime.Now.ToString("hh:mm:ss tt");

            if (string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(age) || string.IsNullOrWhiteSpace(email))
            {
                MessageBox.Show("Please fill all fields.");
                return;
            }

            string[] row = { name, age, email, date, time };
            dgvData.Rows.Add(row);

            SaveToLogFile(name, age, email, date, time);

            txtName.Clear();
            txtAge.Clear();
            txtEmail.Clear();

            lblCount.Text = $"Entries: {dgvData.Rows.Count}";
        }

        private void SaveToLogFile(string name, string age, string email, string date, string time)
        {
            string folderPath = @"C:\wpf_crud\log";
            string filePath = Path.Combine(folderPath, date + ".txt");

            try
            {
                if (!Directory.Exists(folderPath))
                    Directory.CreateDirectory(folderPath);

                using (StreamWriter sw = new StreamWriter(filePath, true))
                {
                    sw.WriteLine($"Time: {time} | Name: {name} | Age: {age} | Email: {email}");
                    sw.WriteLine();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error writing to log: " + ex.Message);
            }
        }
    }
}
